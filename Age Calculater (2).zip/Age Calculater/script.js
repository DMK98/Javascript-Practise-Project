"use strict"
let isDobOpen = false;
let dateOfBirth;
let gear = document.querySelector("#gear");
let ageContent = document.querySelector("#age-content");
const initialText = document.querySelector("#initialtext");
const afterDobButton = document.querySelector("#afterDobButton");
const checkButton = document.querySelector("#checkButton");
const dateinput = document.querySelector("#dateinput");
console.log(initialText);
console.log(afterDobButton);
console.log(checkButton);
// console.log(dateinput);
// console.log(afterDobButton);
const yearEl = document.querySelector("#year");
const monthEl = document.querySelector("#month");
const dayEl = document.querySelector("#day");
const hoursEl = document.querySelector("#hours");
const minutesEl = document.querySelector("#minutes");
const secondEl = document.querySelector("#second");
const makeTwodigitNumber = (number) => {
    return number > 9 ? number : `0${number}`;
}

const toggleDobSelector = () => {
    if (isDobOpen) {
        ageContent.classList.add("hide");
    } else {
        ageContent.classList.remove("hide");
    }
    isDobOpen = !isDobOpen
    console.log("toggle", isDobOpen);
};
// ===========check from belo==============
const updateAge=()=>{
  const currentDate= new Date()
//   console.log({currentDate});
const dateDiff=currentDate-dateOfBirth;
const year =Math.floor(dateDiff/(1000*60*60*24*365))
const month =Math.floor(dateDiff/(1000*60*60*24*365)%12)
const day =Math.floor(dateDiff/(1000*60*60*24)%30)
const hours =Math.floor(dateDiff/(1000*60*60)%24)
const minutes =Math.floor(dateDiff/(1000*60)%60)
const second =Math.floor(dateDiff/(1000)%60)
console.log(dateDiff);
console.log({year,month,day,hours,minutes,second});
yearEl.innerHTML=makeTwodigitNumber(year); 
monthEl.innerHTML=makeTwodigitNumber(month); 
dayEl.innerHTML=makeTwodigitNumber(day); 
hoursEl.innerHTML=makeTwodigitNumber(hours); 
minutesEl.innerHTML=makeTwodigitNumber(minutes); 
secondEl.innerHTML=makeTwodigitNumber(second); 
}
 
// ===========check from belo==============
const setHandleDob = () => {
    const dateString = dateinput.value;
    dateOfBirth = dateString ? new Date(dateString):null;
    const year=localStorage.getItem('year');
    const month=localStorage.getItem('month');
    const day=localStorage.getItem('day');
    const hours=localStorage.getItem('hours');
    const minutes=localStorage.getItem('minutes');
    const second=localStorage.getItem('second');
    // if(year&&month&&day){
       
        
    //     dateOfBirth=new Date(year,month,day,hours,minutes,second );
    // }
    // console.log(dateOfBirth);
    if (dateOfBirth) {
        localStorage.setItem('year',dateOfBirth.getFullYear());
        localStorage.setItem('month',dateOfBirth.getMonth());
        localStorage.setItem('day',dateOfBirth.getDay());
        localStorage.setItem('hours',dateOfBirth.getHours());
        localStorage.setItem('minutes',dateOfBirth.getMinutes());
        localStorage.setItem('second',dateOfBirth.getSeconds());
        initialText.classList.add("hide");
        afterDobButton.classList.remove("hide");
        setInterval(() => updateAge(), 1000);
    } else {
        afterDobButton.classList.add("hide");
        initialText.classList.remove("hide");
    }
}
setHandleDob();
// +++++++++++++++++

// +++++++++++++




gear.addEventListener("click", toggleDobSelector);
checkButton.addEventListener("click", setHandleDob)
