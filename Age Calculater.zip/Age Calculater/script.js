"use strict"
let isDobOpen = false;
let dateOfBirth;
let gear = document.querySelector("#gear");
let ageContent = document.querySelector("#age-content");
const initialText = document.querySelector("#initialtext");
const afterDobButton = document.querySelector("#afterDobButton");
const sendButton = document.querySelector("#sendButton");
const dateinput = document.querySelector("#dateinput");
console.log(initialText);
console.log(afterDobButton);
console.log(sendButton);
// console.log(dateinput);
// console.log(afterDobButton);


const toggleDobSelector = () => {
    if (isDobOpen) {
        ageContent.classList.add("hide");
    } else {
        ageContent.classList.remove("hide");
    }
    isDobOpen = !isDobOpen
    console.log("toggle", isDobOpen);
};

const setHandleDob = () => {
    dateOfBirth=dateinput.value;
    console.log(dateOfBirth);
}
gear.addEventListener("click", toggleDobSelector);  
sendButton.addEventListener("click", setHandleDob)
